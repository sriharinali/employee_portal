![Employee-Management Capture (1)](https://user-images.githubusercontent.com/96341377/223797143-f532750f-cb32-4e75-9e87-937b89c2787b.png)
![Employee-Management Capture (2)](https://user-images.githubusercontent.com/96341377/223797173-772282a4-7596-4e1d-af76-bd635c49eb42.png)
![Employee-Management Capture (3)](https://user-images.githubusercontent.com/96341377/223797184-1aed7dd2-bb91-4155-a247-e6553e5a4f99.png)
![Employee-Management Capture (4)](https://user-images.githubusercontent.com/96341377/223797197-af69919e-467f-4163-91ef-6c4be20af5b8.png)
